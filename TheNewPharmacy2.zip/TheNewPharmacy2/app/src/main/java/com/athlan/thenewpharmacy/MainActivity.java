package com.athlan.thenewpharmacy;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    WebView web_view;
    Button noconnection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Toolbar toolbar = findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

        noconnection = (Button) findViewById(R.id.nointernet);

        noconnection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!DetectConnection.checkInternetConnection(getApplicationContext())) {
                    Toast.makeText(getApplicationContext(), "No Internet! Please Reconnect & Try Again ", Toast.LENGTH_SHORT).show();
                    noconnection.setVisibility(View.VISIBLE);
                } else {
                    loadweb();
                }
            }

        });

        if (!DetectConnection.checkInternetConnection(this)) {
            Toast.makeText(getApplicationContext(), "No Internet! Please Reconnect & Try Again ", Toast.LENGTH_SHORT).show();
            noconnection.setVisibility(View.VISIBLE);
        } else {
            loadweb();
        }
    }

    public void loadweb(){

        noconnection.setVisibility(View.GONE);
        web_view = findViewById(R.id.webpanel);
        web_view.setVerticalScrollBarEnabled(true);
        web_view.requestFocus();
        web_view.getSettings().setDefaultTextEncodingName("utf-8");
        web_view.getSettings().setJavaScriptEnabled(true);
        web_view.loadUrl("https://thenewpharmacy.athlan.global/");
        web_view.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
        });

        web_view.setWebViewClient(new WebViewClient() {
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                web_view.loadData("", "text/html; charset=utf-8", "UTF-8");
                noconnection.setVisibility(View.VISIBLE);
            }
        });

        web_view.setWebChromeClient(new WebChromeClient() {
            public void onProgressChanged(WebView view, int progress) {
                if (progress < 100) {
                    //progressDialog.show();
                }
                if (progress == 100) {
                    //progressDialog.dismiss();
                }
            }
        });

    }

    @Override
    public void onBackPressed() {
        if(web_view!= null && web_view.canGoBack())
            web_view.goBack();// if there is previous page open it
        else
            super.onBackPressed();//if there is no previous page, close app
    }

}
